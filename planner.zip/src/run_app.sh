#!/bin/bash

ruby planner.rb
